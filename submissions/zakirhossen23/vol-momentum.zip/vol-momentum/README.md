# Packaged submission: vol-momentum

This folder is the packaged submission copy. It mirrors the files included in
the `vol-momentum/` folder at the repo root and is the content used to create
the submission zip `submissions/zakirhossen23/vol-momentum.zip`.

Files included:
- `example_crossover.py` (strategy implementation)
- `startup.py`
- `requirements.txt`
- `Dockerfile`
- `README.md`
